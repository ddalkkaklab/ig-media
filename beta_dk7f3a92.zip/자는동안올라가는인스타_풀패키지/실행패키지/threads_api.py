# -*- coding: utf-8 -*-
"""Threads API helper — 스레드 자동 발행 패키지용 (공식 graph.threads.net).
토큰은 .env의 THREADS_TOKEN."""
import json, os, sys, time, urllib.request, urllib.parse

BASE = "https://graph.threads.net/v1.0"
ENV = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")

def _token():
    with open(ENV, encoding="utf-8-sig") as f:
        for line in f:
            if line.startswith("THREADS_TOKEN="):
                t = line.split("=", 1)[1].strip()
                if t:
                    return t
    raise SystemExit("no THREADS_TOKEN in .env")

def has_token():
    try:
        _token()
        return True
    except SystemExit:
        return False

def _call(method, path, params=None):
    params = dict(params or {})
    params["access_token"] = _token()
    qs = urllib.parse.urlencode(params)
    url = f"{BASE}{path}"
    if method == "GET":
        req = urllib.request.Request(f"{url}?{qs}")
    else:
        req = urllib.request.Request(url, data=qs.encode(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        return {"error": True, "status": e.code, "body": body}

def me():
    return _call("GET", "/me", {"fields": "id,username,name"})

def publish(text, reply_to_id=None, image_url=None):
    """글 발행 (2단계: 컨테이너 생성 -> 발행). reply_to_id 주면 답글, image_url 주면 이미지 글."""
    params = {"media_type": "IMAGE" if image_url else "TEXT", "text": text}
    if image_url:
        params["image_url"] = image_url
    if reply_to_id:
        params["reply_to_id"] = reply_to_id
    c = _call("POST", "/me/threads", params)
    if c.get("error") or "id" not in c:
        return {"step": "container", **c}
    time.sleep(5 if image_url else 2)
    p = _call("POST", "/me/threads_publish", {"creation_id": c["id"]})
    return {"step": "publish", "container": c["id"], **p}

def my_posts(limit=10):
    return _call("GET", "/me/threads", {
        "fields": "id,text,timestamp,permalink", "limit": str(limit)})

def insights(post_id):
    return _call("GET", f"/{post_id}/insights", {"metric": "views,likes,replies,reposts,shares"})

def refresh_token():
    """토큰 갱신 — .env의 다른 항목(IG_TOKEN 등)은 보존한다."""
    r = _call("GET", "/refresh_access_token", {"grant_type": "th_refresh_token"})
    if "access_token" in r:
        lines = []
        with open(ENV, encoding="utf-8-sig") as f:
            for line in f:
                if not line.startswith("THREADS_TOKEN="):
                    lines.append(line.rstrip("\n"))
        lines.append("THREADS_TOKEN=" + r["access_token"])
        with open(ENV, "w", encoding="utf-8") as f:
            f.write("\n".join(l for l in lines if l.strip()) + "\n")
    return {k: r.get(k) for k in ("token_type", "expires_in") if k in r} or r

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "me"
    if cmd == "me":
        out = me()
    elif cmd == "posts":
        out = my_posts()
    elif cmd == "insights":
        out = insights(sys.argv[2])
    elif cmd == "refresh":
        out = refresh_token()
    else:
        out = {"error": "unknown cmd"}
    print(json.dumps(out, ensure_ascii=False, indent=2))
