# -*- coding: utf-8 -*-
"""Instagram Graph API helper — 인스타 자동 발행 패키지용.
'Instagram API with Instagram Login' 방식 (graph.instagram.com, 페이스북 페이지 불필요).
threads_api.py와 동일한 구조. 토큰은 .env의 IG_TOKEN."""
import json, os, sys, time, urllib.request, urllib.parse

BASE = "https://graph.instagram.com/v23.0"
ENV = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")

def _token():
    with open(ENV, encoding="utf-8-sig") as f:
        for line in f:
            if line.startswith("IG_TOKEN="):
                t = line.split("=", 1)[1].strip()
                if t:
                    return t
    raise SystemExit("no IG_TOKEN in .env")

def has_token():
    try:
        _token()
        return True
    except SystemExit:
        return False

def _call(method, path, params=None):
    params = dict(params or {})
    params["access_token"] = _token()
    qs = urllib.parse.urlencode(params)
    url = f"{BASE}{path}"
    if method == "GET":
        req = urllib.request.Request(f"{url}?{qs}")
    else:
        req = urllib.request.Request(url, data=qs.encode(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        return {"error": True, "status": e.code, "body": body}

def me():
    return _call("GET", "/me", {"fields": "user_id,username,name,account_type,media_count"})

def _wait_ready(container_id, tries=20):
    """컨테이너 처리 완료 대기 (영상/캐러셀은 수 초~수십 초 걸림)"""
    for _ in range(tries):
        st = _call("GET", f"/{container_id}", {"fields": "status_code"})
        if st.get("status_code") == "FINISHED":
            return True
        if st.get("status_code") == "ERROR" or st.get("error"):
            return False
        time.sleep(3)
    return False

def publish_image(image_url, caption=""):
    """피드 이미지 1장 발행 (2단계: 컨테이너 -> 발행)"""
    c = _call("POST", "/me/media", {"image_url": image_url, "caption": caption})
    if c.get("error") or "id" not in c:
        return {"step": "container", **c}
    time.sleep(5)
    p = _call("POST", "/me/media_publish", {"creation_id": c["id"]})
    return {"step": "publish", "container": c["id"], **p}

def publish_carousel(image_urls, caption=""):
    """캐러셀(카드뉴스) 발행 — 자식 컨테이너들 -> 캐러셀 컨테이너 -> 발행"""
    children = []
    for u in image_urls:
        c = _call("POST", "/me/media", {"image_url": u, "is_carousel_item": "true"})
        if c.get("error") or "id" not in c:
            return {"step": "child_container", "failed_url": u, **c}
        children.append(c["id"])
        time.sleep(2)
    car = _call("POST", "/me/media", {
        "media_type": "CAROUSEL", "children": ",".join(children), "caption": caption})
    if car.get("error") or "id" not in car:
        return {"step": "carousel_container", **car}
    if not _wait_ready(car["id"]):
        return {"step": "carousel_wait", "error": True, "container": car["id"]}
    p = _call("POST", "/me/media_publish", {"creation_id": car["id"]})
    return {"step": "publish", "container": car["id"], **p}

def publish_story(image_url):
    """스토리 발행 (링크 스티커는 API 미지원 — 링크는 프로필로 유도)"""
    c = _call("POST", "/me/media", {"media_type": "STORIES", "image_url": image_url})
    if c.get("error") or "id" not in c:
        return {"step": "container", **c}
    time.sleep(5)
    p = _call("POST", "/me/media_publish", {"creation_id": c["id"]})
    return {"step": "publish", "container": c["id"], **p}

def publish_reel(video_url, caption=""):
    """릴스 발행 (video_url은 공개 mp4)"""
    c = _call("POST", "/me/media", {"media_type": "REELS", "video_url": video_url, "caption": caption})
    if c.get("error") or "id" not in c:
        return {"step": "container", **c}
    if not _wait_ready(c["id"], tries=40):
        return {"step": "video_wait", "error": True, "container": c["id"]}
    p = _call("POST", "/me/media_publish", {"creation_id": c["id"]})
    return {"step": "publish", "container": c["id"], **p}

def my_media(limit=10):
    return _call("GET", "/me/media", {
        "fields": "id,caption,media_type,permalink,timestamp,like_count,comments_count",
        "limit": str(limit)})

def insights(media_id):
    return _call("GET", f"/{media_id}/insights", {"metric": "reach,likes,comments,saved,shares,views"})

def comments_of(media_id):
    return _call("GET", f"/{media_id}/comments", {"fields": "id,text,username,timestamp"})

def reply_comment(comment_id, text):
    return _call("POST", f"/{comment_id}/replies", {"message": text})

def publishing_limit():
    return _call("GET", "/me/content_publishing_limit", {})

def refresh_token():
    """장수명 토큰 갱신 (60일 → 새 60일). 발급 24시간 후부터 가능."""
    r = _call("GET", "/refresh_access_token", {"grant_type": "ig_refresh_token"})
    if "access_token" in r:
        lines = []
        with open(ENV, encoding="utf-8-sig") as f:
            for line in f:
                if not line.startswith("IG_TOKEN="):
                    lines.append(line.rstrip("\n"))
        lines.append("IG_TOKEN=" + r["access_token"])
        with open(ENV, "w", encoding="utf-8") as f:
            f.write("\n".join(l for l in lines if l.strip()) + "\n")
    return {k: r.get(k) for k in ("token_type", "expires_in") if k in r} or r

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "me"
    if cmd == "me":
        out = me()
    elif cmd == "publish":       # publish <image_url> [caption파일]
        cap = open(sys.argv[3], encoding="utf-8-sig").read().strip() if len(sys.argv) > 3 else ""
        out = publish_image(sys.argv[2], cap)
    elif cmd == "carousel":      # carousel <url1,url2,..> [caption파일]
        cap = open(sys.argv[3], encoding="utf-8-sig").read().strip() if len(sys.argv) > 3 else ""
        out = publish_carousel(sys.argv[2].split(","), cap)
    elif cmd == "story":
        out = publish_story(sys.argv[2])
    elif cmd == "media":
        out = my_media()
    elif cmd == "insights":
        out = insights(sys.argv[2])
    elif cmd == "comments":
        out = comments_of(sys.argv[2])
    elif cmd == "limit":
        out = publishing_limit()
    elif cmd == "refresh":
        out = refresh_token()
    else:
        out = {"error": "unknown cmd"}
    print(json.dumps(out, ensure_ascii=False, indent=2))
