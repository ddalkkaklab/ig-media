# 인스타 자동 발행 패키지 — 빠른 시작

전자책 3부를 따라오셨다면 이 순서만 남았습니다.

## 1. 준비
1. `.env.example`을 복사해 `.env`로 저장 → `IG_TOKEN=`, `GH_TOKEN=` 값 입력 (전자책 10~11장)
2. `config.json` 열어서 브랜드 이름·한 줄 소개·발행 시각·GitHub 아이디/저장소 입력

## 2. 확인
```
python instagram_api.py me        ← 내 인스타 아이디 나오면 토큰 OK
python make_poster.py render e1   ← output 폴더에 포스터 PNG 생기면 렌더링 OK
```

## 3. 자동화 켜기
`설치.bat` 더블클릭 → 끝.

바로 테스트: `python auto_publish.py` (설정 시각이 지났다면 1~2분 내 발행됩니다)

## 파일 구성
| 파일 | 역할 |
|---|---|
| `config.json` | 브랜드·발행시각·GitHub 설정 (여기만 만지면 됨) |
| `.env` | 토큰 2개 (비밀번호처럼 관리) |
| `content_db.json` | 글감 창고 — `리필_프롬프트.txt`로 AI한테 리필 |
| `templates/` | 포스터 디자인 6종 |
| `make_poster.py` | 글감 → 포스터 PNG |
| `github_upload.py` | 포스터 → 공개 URL (무료) |
| `auto_publish.py` | 매일 자동 발행 (스케줄러가 실행) |
| `instagram_api.py` | 인스타 공식 API 연결 |
| `설치.bat` / `제거.bat` | 자동화 켜기/끄기 |
| `publish_log.txt` | 발행 일기 (자동 생성) |
| `metrics.csv` | 게시물 성과 기록 (자동 생성) |

## 막히면
1. 에러 메시지를 **그대로 복사**해서 AI한테: "auto_publish.py 실행했더니 이 에러: [붙여넣기]. 고쳐줘."
2. 그래도 안 되면 크몽 메시지로 물어보세요. (구매 후 30일)

## 주의
- 광고형 템플릿(t5/t6)은 배경 이미지가 필요합니다 — 전자책 부록의 선택 사항입니다. 기본 4종(감성/카드/스토리/대화)은 배경 없이 바로 됩니다.
- `.env`와 토큰은 절대 공유 금지.
