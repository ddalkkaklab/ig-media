@echo off
chcp 65001 >nul
echo.
echo  [자동 발행기 설치]
echo  10분마다 확인해서, 매일 설정 시각 이후 첫 확인 때 발행합니다.
echo.
schtasks /create /f /sc minute /mo 10 /tn "IgAutoPublish" /tr "pythonw \"%~dp0auto_publish.py\""
if %errorlevel%==0 (
  echo.
  echo  설치 완료. 이제 컴퓨터가 켜져 있으면 알아서 발행됩니다.
  echo  지금 바로 테스트하려면:  python auto_publish.py
) else (
  echo.
  echo  설치 실패. 이 창을 캡처해서 AI한테 물어보세요.
)
echo.
pause
