# -*- coding: utf-8 -*-
"""GitHub 무료 이미지 호스팅 — 포스터 PNG를 내 GitHub 저장소에 올리고
인스타 API가 읽을 수 있는 공개 주소(raw URL)를 돌려준다.
필요한 것: .env의 GH_TOKEN, config.json의 github 항목."""
import base64, json, os, urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
ENV = os.path.join(BASE, ".env")
CONFIG = os.path.join(BASE, "config.json")

def _gh_token():
    with open(ENV, encoding="utf-8-sig") as f:
        for line in f:
            if line.startswith("GH_TOKEN="):
                t = line.split("=", 1)[1].strip()
                if t:
                    return t
    raise SystemExit("no GH_TOKEN in .env — 전자책 11장을 다시 확인하세요")

def _cfg():
    with open(CONFIG, encoding="utf-8-sig") as f:
        return json.load(f)["github"]

def _api(method, url, payload=None):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": f"Bearer {_gh_token()}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "ig-auto-publish",
    })
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": True, "status": e.code, "body": e.read().decode(errors="replace")[:300]}

def upload_file(path):
    """파일 하나 업로드 → 공개 raw URL 반환. 같은 이름이 있으면 덮어쓴다."""
    g = _cfg()
    name = os.path.basename(path)
    api_url = f"https://api.github.com/repos/{g['user']}/{g['repo']}/contents/{name}"
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    payload = {"message": f"auto upload {name}", "content": b64, "branch": g.get("branch", "main")}
    r = _api("PUT", api_url, payload)
    if r.get("error") and r.get("status") == 422:
        # 같은 이름 파일이 이미 있음 → sha 조회 후 덮어쓰기
        cur = _api("GET", f"{api_url}?ref={g.get('branch', 'main')}")
        if "sha" in cur:
            payload["sha"] = cur["sha"]
            r = _api("PUT", api_url, payload)
    if r.get("error"):
        raise RuntimeError(f"github upload failed: {json.dumps(r, ensure_ascii=False)[:200]}")
    raw = f"https://raw.githubusercontent.com/{g['user']}/{g['repo']}/{g.get('branch', 'main')}/{name}"
    # 실제로 서빙되는지 확인
    with urllib.request.urlopen(raw, timeout=30) as resp:
        if resp.status != 200:
            raise RuntimeError(f"url not served: {raw}")
    return raw

def upload_files(paths):
    return [upload_file(p) for p in paths]

if __name__ == "__main__":
    import sys
    for p in sys.argv[1:]:
        print(upload_file(p))
