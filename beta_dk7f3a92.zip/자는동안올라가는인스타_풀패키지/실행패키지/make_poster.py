# -*- coding: utf-8 -*-
"""포스터 렌더러 — content_db.json 아이템을 HTML 템플릿에 넣고
Edge/Chrome headless로 1080x1350 PNG 스크린샷을 뽑는다.
브랜드 문구는 config.json에서 읽어 템플릿의 {{BRAND}} 등에 주입된다."""
import html, json, os, shutil, subprocess, sys

BASE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(BASE, "templates")
OUT = os.path.join(BASE, "output")
DB = os.path.join(BASE, "content_db.json")
CONFIG = os.path.join(BASE, "config.json")

EDGE_CANDIDATES = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
]

def load_config():
    with open(CONFIG, encoding="utf-8-sig") as f:
        return json.load(f)

def _browser():
    for p in EDGE_CANDIDATES:
        if os.path.exists(p):
            return p
    raise SystemExit("Edge/Chrome을 찾지 못했습니다. 둘 중 하나가 설치되어 있어야 합니다.")

def _tpl(name):
    with open(os.path.join(TPL, name), encoding="utf-8") as f:
        t = f.read()
    b = load_config()["brand"]
    return (t.replace("{{BRAND}}", b.get("name", ""))
             .replace("{{TAGLINE}}", b.get("tagline", ""))
             .replace("{{CHIP1}}", b.get("chip1", ""))
             .replace("{{CHIP2}}", b.get("chip2", "")))

def _esc(text):
    return html.escape(text, quote=False).replace("\n", "<br>")

def _shot(html_str, png_name):
    os.makedirs(OUT, exist_ok=True)
    html_path = os.path.join(OUT, png_name.replace(".png", ".html"))
    png_path = os.path.join(OUT, png_name)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_str)
    subprocess.run([
        _browser(), "--headless=new", "--disable-gpu", "--hide-scrollbars",
        "--force-device-scale-factor=1", "--window-size=1080,1350",
        f"--screenshot={png_path}",
        "file:///" + html_path.replace("\\", "/"),
    ], capture_output=True, timeout=120)
    if not os.path.exists(png_path):
        raise RuntimeError(f"screenshot failed: {png_name}")
    os.remove(html_path)
    return png_path

def _chat_messages_html(messages):
    parts = []
    for m in messages:
        if m["s"] == "DIV":
            parts.append(f'<div class="divider"><span>──── &nbsp;{_esc(m["t"])}&nbsp; ────</span></div>')
        elif m["s"] == "L":
            parts.append(
                '<div class="row L"><div class="avatar"></div><div class="col">'
                f'<div class="name">{_esc(m.get("name", ""))}</div>'
                f'<div class="msg">{_esc(m["t"])}</div></div></div>')
        else:
            parts.append(f'<div class="row R"><div class="msg">{_esc(m["t"])}</div></div>')
    return "\n".join(parts)

# 광고형 포스터 강조색 프리셋
ACCENTS = {
    "pink":   {"a": "#ff5f8f", "d": "#d63d6e", "cta_text": "#ffffff"},
    "yellow": {"a": "#ffc400", "d": "#e09b00", "cta_text": "#1a1205"},
    "purple": {"a": "#b18cff", "d": "#8a5fe0", "cta_text": "#ffffff"},
}

def _render_ad(item, pid):
    ac = ACCENTS.get(item.get("accent", "pink"), ACCENTS["pink"])
    checks = "\n".join(
        f'<div class="chk"><div class="ic">✓</div><div class="tx">{_esc(c)}</div></div>'
        for c in item.get("checks", []))
    h = (_tpl("t5_ad.html")
         .replace("{{ACCENT_DARK}}", ac["d"])
         .replace("{{ACCENT}}", ac["a"])
         .replace("{{CTA_TEXT}}", ac["cta_text"])
         .replace("{{BG}}", f"../assets/{item['bg']}.png")
         .replace("{{HANDWRITE}}", _esc(item.get("handwrite", "")))
         .replace("{{HOOK_HTML}}", item["hook_html"])
         .replace("{{CHECKS}}", checks)
         .replace("{{CARD_LINES}}", item["card_lines"])
         .replace("{{CTA}}", _esc(item["cta"])))
    return [_shot(h, f"{pid}.png")]

def _render_prime(item, pid):
    bullets = "\n".join(
        f'<div class="bl"><span class="s">✦</span>{_esc(b)}</div>'
        for b in item.get("bullets", []))
    h = (_tpl("t6_prime.html")
         .replace("{{BG}}", f"../assets/{item['bg']}.png")
         .replace("{{PRE}}", _esc(item.get("pre", "")))
         .replace("{{HOOK_HTML}}", item["hook_html"])
         .replace("{{SUB}}", _esc(item.get("sub", "")))
         .replace("{{BULLETS}}", bullets)
         .replace("{{CTA}}", _esc(item.get("cta", "지금 확인하기")))
         .replace("{{MICRO}}", _esc(item.get("micro", "프로필 링크에서 1분이면 확인할 수 있어요"))))
    return [_shot(h, f"{pid}.png")]

def render_item(item, prefix=""):
    """아이템 하나 → PNG 경로 리스트 (캐러셀이면 여러 장)"""
    pid = f"{prefix}{item['id']}"
    t = item["template"]
    if t == "ad":
        return _render_ad(item, pid)
    if t == "prime":
        return _render_prime(item, pid)
    if t == "emotion":
        bg = item.get("bg", "")
        photo = f'<div class="photo" style="background-image:url(\'../assets/{bg}.png\')"></div>' if bg else ""
        h = (_tpl("t1_emotion.html").replace("{{PHOTO}}", photo)
             .replace("{{HOOK}}", _esc(item["hook"])).replace("{{SUB}}", _esc(item["sub"])))
        return [_shot(h, f"{pid}.png")]
    if t == "card":
        h = _tpl("t3_card.html").replace("{{HOOK}}", _esc(item["hook"])).replace("{{SUB}}", _esc(item["sub"]))
        return [_shot(h, f"{pid}.png")]
    if t == "story":
        h = _tpl("t4_story.html").replace("{{STORY}}", _esc(item["story"])).replace("{{WHO}}", _esc(item["who"]))
        return [_shot(h, f"{pid}.png")]
    if t == "chat":
        out = []
        cover = _tpl("t2_chat_cover.html").replace("{{HOOK}}", _esc(item["hook"])).replace("{{PREVIEW}}", _esc(item["preview"]))
        out.append(_shot(cover, f"{pid}_1.png"))
        for i, slide in enumerate(item["slides"], start=2):
            s = (_tpl("t2_chat_slide.html")
                 .replace("{{CHAT_NAME}}", _esc(item["chat_name"]))
                 .replace("{{MESSAGES}}", _chat_messages_html(slide["messages"])))
            out.append(_shot(s, f"{pid}_{i}.png"))
        final = _tpl("t2_chat_final.html").replace("{{TEASER}}", _esc(item["teaser"])).replace("{{CTA}}", _esc(item["cta"]))
        out.append(_shot(final, f"{pid}_{len(item['slides']) + 2}.png"))
        return out
    raise ValueError(f"unknown template: {t}")

def load_db():
    with open(DB, encoding="utf-8-sig") as f:
        return json.load(f)

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    db = load_db()
    if cmd == "render":  # render <item_id>
        item = next(i for i in db["items"] if i["id"] == sys.argv[2])
        for p in render_item(item):
            print(p)
    elif cmd == "all":
        for item in db["items"]:
            for p in render_item(item):
                print(p)
    elif cmd == "clean":
        shutil.rmtree(OUT, ignore_errors=True)
        print("cleaned")
