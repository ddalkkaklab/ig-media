@echo off
chcp 65001 >nul
schtasks /delete /f /tn "IgAutoPublish"
echo 자동 발행기가 제거되었습니다. (파일은 그대로 남습니다)
pause
