# -*- coding: utf-8 -*-
"""인스타 자동 발행기 — 윈도우 작업 스케줄러가 10분마다 실행.
매일 config.json의 발행 시각 이후 첫 실행에서 content_db.json의 다음 아이템을
렌더링 → GitHub 업로드 → 인스타 발행. 컴퓨터가 켜져 있으면 알아서 돌아간다.
.env에 IG_TOKEN이 없으면 아무것도 하지 않는다."""
import datetime, json, os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import instagram_api, make_poster, github_upload, threads_api

DB = os.path.join(BASE, "content_db.json")
LOG = os.path.join(BASE, "publish_log.txt")
LOCK = os.path.join(BASE, ".publish.lock")
METRICS = os.path.join(BASE, "metrics.csv")
METRICS_HOUR = 21  # 매일 21시 이후 첫 실행에서 최근 게시물 성과 스냅샷 기록

def _post_time():
    p = make_poster.load_config().get("post", {})
    return int(p.get("hour", 19)), int(p.get("minute", 30))

def log(msg):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"[{ts}] {msg}\n")

def _save_db(db):
    with open(DB, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def _threads_text(item):
    """글감 → 스레드용 텍스트 (해시태그 없이, hook 중심)"""
    t = item.get("template")
    if t == "story":
        return item.get("story", "")
    parts = [item.get("hook", "")]
    if t in ("emotion", "card") and item.get("sub"):
        parts.append(item["sub"])
    if t == "chat" and item.get("teaser"):
        parts.append(item["teaser"])
    return "\n\n".join(p for p in parts if p)

def post_threads(item):
    """스레드 동시 발행 — THREADS_TOKEN 없으면 조용히 건너뜀. 실패해도 치명적이지 않음."""
    if not threads_api.has_token():
        return
    text = _threads_text(item)
    if not text:
        return
    r = threads_api.publish(text)
    if r.get("id") and not r.get("error"):
        log(f"THREADS_PUBLISHED {item['id']} -> {r['id']}")
    else:
        log(f"THREADS_ERROR {item['id']}: {json.dumps(r, ensure_ascii=False)[:200]}")

def post_daily(db, now):
    today = now.strftime("%Y-%m-%d")
    if db.get("last_posted_date") == today:
        return
    hour, minute = _post_time()
    if (now.hour, now.minute) < (hour, minute):
        return
    idx = db.get("next_index", 0) % len(db["items"])
    item = db["items"][idx]
    # 파일명에 날짜를 붙여 캐시 충돌 방지
    prefix = now.strftime("%Y%m%d_")
    pngs = make_poster.render_item(item, prefix=prefix)
    urls = github_upload.upload_files(pngs)
    cap = item.get("caption", "")
    if len(urls) == 1:
        r = instagram_api.publish_image(urls[0], cap)
    else:
        r = instagram_api.publish_carousel(urls, cap)
    if r.get("id") and not r.get("error"):
        db["last_posted_date"] = today
        db["next_index"] = idx + 1
        _save_db(db)
        log(f"PUBLISHED {item['id']} ({len(urls)}장) -> {r['id']}")
        post_threads(item)
        for p in pngs:
            try: os.remove(p)
            except OSError: pass
    else:
        log(f"ERROR {item['id']}: {json.dumps(r, ensure_ascii=False)[:300]}")

def collect_insights(db, now):
    today = now.strftime("%Y-%m-%d")
    if db.get("last_metrics_date") == today:
        return
    if now.hour < METRICS_HOUR:
        return
    media = instagram_api.my_media(limit=15)
    if media.get("error"):
        log(f"METRICS ERROR: {json.dumps(media, ensure_ascii=False)[:200]}")
        return
    new_file = not os.path.exists(METRICS)
    rows = []
    for m in media.get("data", []):
        ins = instagram_api.insights(m["id"])
        vals = {}
        for it in ins.get("data", []) if not ins.get("error") else []:
            v = (it.get("values") or [{}])[0].get("value")
            vals[it.get("name")] = v if v is not None else ""
        cap = (m.get("caption") or "").replace("\n", " ")[:30].replace(",", " ")
        rows.append(",".join(str(x) for x in [
            today, m["id"], m.get("timestamp", "")[:10], m.get("media_type", ""),
            f'"{cap}"', m.get("like_count", ""), m.get("comments_count", ""),
            vals.get("reach", ""), vals.get("saved", ""), vals.get("shares", ""),
            vals.get("views", "")]))
    with open(METRICS, "a", encoding="utf-8") as f:
        if new_file:
            f.write("snapshot_date,media_id,posted_date,media_type,caption_head,likes,comments,reach,saved,shares,views\n")
        f.write("\n".join(rows) + "\n")
    db["last_metrics_date"] = today
    _save_db(db)
    log(f"METRICS {len(rows)}개 기록")

def weekly_token_refresh(db, now):
    """일요일마다 1회 토큰 갱신 (60일 만료 방지)"""
    if now.weekday() != 6:
        return
    today = now.strftime("%Y-%m-%d")
    if db.get("last_token_refresh") == today:
        return
    r = instagram_api.refresh_token()
    if threads_api.has_token():
        rt = threads_api.refresh_token()
        log(f"THREADS_TOKEN_REFRESH {json.dumps(rt, ensure_ascii=False)[:100]}")
    db["last_token_refresh"] = today
    _save_db(db)
    log(f"TOKEN_REFRESH {json.dumps(r, ensure_ascii=False)[:150]}")

def main():
    if os.path.exists(LOCK):
        age = datetime.datetime.now().timestamp() - os.path.getmtime(LOCK)
        if age < 600:
            return
    open(LOCK, "w").close()
    try:
        if not instagram_api.has_token():
            return  # 토큰 세팅 전 — 조용히 대기
        with open(DB, encoding="utf-8-sig") as f:
            db = json.load(f)
        now = datetime.datetime.now()
        post_daily(db, now)
        collect_insights(db, now)
        weekly_token_refresh(db, now)
    except Exception as e:
        log(f"FATAL: {type(e).__name__}: {e}")
    finally:
        try: os.remove(LOCK)
        except OSError: pass

if __name__ == "__main__":
    main()
